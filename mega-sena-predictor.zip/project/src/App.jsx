import MegaSenaPredictor from './components/MegaSenaPredictor'

function App() {
  return <MegaSenaPredictor />
}

export default App
